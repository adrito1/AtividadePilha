import javax.swing.JOptionPane;

// Classe de Modelagem
class Sapato {
    private String marca;
    private String modelo;
    private int tamanho;

    public Sapato(String marca, String modelo, int tamanho) {
        this.marca = marca;
        this.modelo = modelo;
        this.tamanho = tamanho;
    }

    @Override
    public String toString() {
        return "Sapato [marca=" + marca + ", modelo=" + modelo + ", tamanho=" + tamanho + "]";
    }
}