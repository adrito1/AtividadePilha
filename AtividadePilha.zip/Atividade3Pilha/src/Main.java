// Classe de Visão

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Exemplo de interação com o usuário usando JOptionPane
        String marca = JOptionPane.showInputDialog("Digite a marca do sapato:");
        String modelo = JOptionPane.showInputDialog("Digite o modelo do sapato:");
        int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho do sapato:"));

        // Criando objeto Sapato
        Sapato sapato = new Sapato(marca, modelo, tamanho);

        // Criando uma pilha de sapatos com capacidade para 3 objetos
        PilhaSapato pilha = new PilhaSapato(3);

        // Empilhando o objeto Sapato na pilha
        pilha.empilhar(sapato);

        // Desempilhando e exibindo o objeto Sapato
        Sapato sapatoDesempilhado = pilha.desempilhar();
        if (sapatoDesempilhado != null) {
            JOptionPane.showMessageDialog(null, "Sapato desempilhado: " + sapatoDesempilhado.toString());
        }
    }
}