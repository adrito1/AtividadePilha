// Classe de Negócio (utilizando uma Pilha para armazenar os objetos Sapato)

import javax.swing.JOptionPane;

class PilhaSapato {
    private Sapato[] pilha;
    private int topo;

    public PilhaSapato(int capacidade) {
        pilha = new Sapato[capacidade];
        topo = -1;
    }

    public void empilhar(Sapato sapato) {
        if (topo < pilha.length - 1) {
            pilha[++topo] = sapato;
        } else {
            JOptionPane.showMessageDialog(null, "Pilha cheia!");
        }
    }

    public Sapato desempilhar() {
        if (topo >= 0) {
            return pilha[topo--];
        } else {
            JOptionPane.showMessageDialog(null, "Pilha vazia!");
            return null;
        }
    }
}